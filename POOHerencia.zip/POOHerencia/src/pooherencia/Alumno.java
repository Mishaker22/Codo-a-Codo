/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pooherencia;

/**
 *
 * @author alumno
 */
public class Alumno extends Persona{
    private int matricula;
    private int porcentajeBeca;
    
    public Alumno(String pNombre, String pApellido, int pMatricula
                , int pPorcentajeBeca){
        super(pNombre, pApellido);
        this.matricula = pMatricula;
        this.porcentajeBeca = pPorcentajeBeca;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public int getPorcentajeBeca() {
        return porcentajeBeca;
    }

    public void setPorcentajeBeca(int porcentajeBeca) {
        this.porcentajeBeca = porcentajeBeca;
    }

    public String toString(){
        return super.toString() + " - Matricula: " + matricula 
                + " - Porcentaje de Beca: " + porcentajeBeca; 
    }
    
}
