/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pooherencia;

/**
 *
 * @author alumno
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Persona alumno1 = new Alumno("Juan", "Saldivar", 10001, 30);
        
        System.out.println(alumno1.toString());

        Persona docente1 = new Docente("Federico", "Pineda", "B010"
                            , "Docente Universitario");
       
        System.out.println(docente1);
        
        int[]  numeros = new int[3];
        
        numeros[0] = 23;
        numeros[1] = 45;
        numeros[2] = 3;


        for(int i = 0; i < numeros.length; i++){
            System.out.println(numeros[i]);
        }
        
        Persona[] personas = new Persona[2];
        
        personas[0] = alumno1;
        personas[1] = docente1;
        
        for(int i=0; i < personas.length; i++){
            System.out.println(personas[i].toString());
        }
        
        
        
    }
    
}
