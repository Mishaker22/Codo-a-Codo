/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pooherencia;

/**
 *
 * @author alumno
 */
public class Docente extends Persona{
    private String legajo;
    private String antecedentesAcademicos;

    public Docente (String nombre, String apellido,
                String legajo, String antecedentesAcademicos){
        super(nombre, apellido);
        this.legajo = legajo;
        this.antecedentesAcademicos = antecedentesAcademicos;
    }    
    
    public String getLegajo(){
        return legajo;
    }
    
    public void setLegajo(String legajo){
        this.legajo = legajo;
    }
    
    public String getAntecedentesAcademicos(){
        return antecedentesAcademicos;
    }
    
    public void setAntecedentesAcademicos(String antecedentesAcademicos){
        this.antecedentesAcademicos = antecedentesAcademicos;
    }
    
    public String toString(){
        return super.toString() + " - Legajo: " + legajo  +
                " - Antecedentes Académicos: " + antecedentesAcademicos;
    }
}
