

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
public class Main {

   
    public static void main(String[] args) {
        
       Connection cnn = null;
       ResultSet datos = null;
       ResultSetMetaData metaDatos = null;
       PreparedStatement statement = null;
       
       //usuario de mysql
       String user ="root";
       String pass="admin";
       
       //base de atos con la que debemos trabajar
       
       String url="jdbc:mysql://127.0.0.1/world";
       String driver ="com.mysql.jdbc.Driver";
       
       //variable para cargar consulta
       String consultasSql="";
       
        try {
            Class.forName(driver);
            cnn=DriverManager.getConnection(url, user, pass);
            consultasSql ="SELECT country.name as 'Pais', country.population as 'Habitantes' "
                    + "from world.country order by country.ame asc;";
            statement = cnn.prepareStatement(consultasSql);
            datos = statement.executeQuery();
            metaDatos =datos.getMetaData();
            int cantRegistros=0;
            //opcion 1
            System.out.println("***Pais--Habitantes***");
            while (datos.next()) {            
                System.out.println(datos.getString("Pais") + "--"
                + datos.getString("Habitantes"));
                cantRegistros++;
            }
        } catch (Exception e) {
            System.out.println("hubo un error");
            System.out.println(e.getMessage());
            
        }
       
               
       
       
    }
    
}
